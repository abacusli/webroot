
FrameCenter = function() {
    FrameCenter.superclass.constructor.call(this, {
		id: 'center',
        region:'center',
        margins:'0 0 5 0',
        //resizeTabs: true,
        //minTabWidth: 135,
        //tabWidth: 135,
        plugins: new Ext.ux.TabCloseMenu(),
		deferredRender:false,
        enableTabScroll: true, 
		autoScroll: true,
        activeTab: 0,
		items: [{
            id:'core',
            title: '首页',
            autoLoad: {url: 'core.jsp'},
            autoScroll: true
        }]
    });
};
Ext.extend(FrameCenter, Ext.TabPanel, {

    loadClass : function(node,frameDate){
        var id = node.id;
        var tab = this.getComponent(id);
        if(tab){
            this.setActiveTab(tab);
			//this.remove(tab,true)
        }else{
            var autoLoad = {url: node.attributes.href+'&date='+frameDate};
            var p = this.add(new  Ext.Panel({
                //id: node.id,
				id: node.text+' '+frameDate,
				title: node.text+' '+frameDate,
                autoLoad: autoLoad,
				closable: true,
                autoScroll:true//,
            }));
            this.setActiveTab(p);
        }
    }
});

Ext.reg('framecenter', FrameCenter); 